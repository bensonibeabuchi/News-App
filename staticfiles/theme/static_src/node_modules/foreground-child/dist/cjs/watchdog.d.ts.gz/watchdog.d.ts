/// <reference types="node" />
import { ChildProcess } from 'child_process';
export declare const watchdog: (child: ChildProcess) => ChildProcess;
//# sourceMappingURL=watchdog.d.ts.map