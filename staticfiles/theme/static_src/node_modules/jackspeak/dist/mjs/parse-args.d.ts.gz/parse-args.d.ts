/// <reference types="node" />
import * as util from 'util';
export declare const parseArgs: typeof util.parseArgs;
//# sourceMappingURL=parse-args-esm.d.ts.map