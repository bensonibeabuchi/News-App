import { RimrafAsyncOptions, RimrafSyncOptions } from '.';
export declare const rimrafWindows: (path: string, opt: RimrafAsyncOptions) => Promise<boolean>;
export declare const rimrafWindowsSync: (path: string, opt: RimrafSyncOptions) => boolean;
//# sourceMappingURL=rimraf-windows.d.ts.map