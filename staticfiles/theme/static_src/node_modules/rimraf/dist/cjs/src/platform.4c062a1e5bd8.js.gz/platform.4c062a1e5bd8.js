"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = process.env.__TESTING_RIMRAF_PLATFORM__ || process.platform;
//# sourceMappingURL=platform.js.d0c2df6ad618.map