import { RimrafAsyncOptions, RimrafSyncOptions } from '.';
export declare const rimrafPosix: (path: string, opt: RimrafAsyncOptions) => Promise<boolean>;
export declare const rimrafPosixSync: (path: string, opt: RimrafSyncOptions) => boolean;
//# sourceMappingURL=rimraf-posix.d.ts.map