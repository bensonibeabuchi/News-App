import { RimrafAsyncOptions, RimrafSyncOptions } from '.';
export declare const rimrafMoveRemove: (path: string, opt: RimrafAsyncOptions) => Promise<boolean>;
export declare const rimrafMoveRemoveSync: (path: string, opt: RimrafSyncOptions) => boolean;
//# sourceMappingURL=rimraf-move-remove.d.ts.map