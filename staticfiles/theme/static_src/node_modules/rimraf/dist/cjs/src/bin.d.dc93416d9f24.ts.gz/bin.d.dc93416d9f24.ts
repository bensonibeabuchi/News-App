#!/usr/bin/env node
export declare const help: string;
declare const main: {
    (...args: string[]): Promise<0 | 1>;
    help: string;
};
export default main;
//# sourceMappingURL=bin.d.ts.map