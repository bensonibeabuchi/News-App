export declare const rimrafManual: (path: string, opt: import("./index.js").RimrafAsyncOptions) => Promise<boolean>;
export declare const rimrafManualSync: (path: string, opt: import("./index.js").RimrafSyncOptions) => boolean;
//# sourceMappingURL=rimraf-manual.d.ts.map