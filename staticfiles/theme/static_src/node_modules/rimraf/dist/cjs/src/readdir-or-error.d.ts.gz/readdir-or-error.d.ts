/// <reference types="node" />
/// <reference types="node" />
export declare const readdirOrError: (path: string) => Promise<NodeJS.ErrnoException | import("fs").Dirent[]>;
export declare const readdirOrErrorSync: (path: string) => NodeJS.ErrnoException | import("fs").Dirent[];
//# sourceMappingURL=readdir-or-error.d.ts.map